import requests
import os

# Remplacez par vos informations d'identification Imgur
client_id = "dbad42f279f3dc8"

# Titre de l'album
album_title = "Mon album d'images"

# Création de l'album
headers = {
    "Authorization": f"Client-ID {client_id}",
}

data = {
    "title": album_title
}

response = requests.post("https://api.imgur.com/3/album", headers=headers, data=data)

if response.status_code == 200:
    album_id = response.json()["data"]["id"]
    print(f"Album créé avec succès: {album_id}")
else:
    print(f"Erreur lors de la création de l'album: {response.status_code}")

# Téléchargement des images vers l'album
def upload_image(image_path, album_id):
    headers = {
        "Authorization": f"Client-ID {client_id}",
    }

    with open(image_path, "rb") as image_file:
        response = requests.post(
            "https://api.imgur.com/3/image",
            headers=headers,
            data={
                "image": image_file,
                "album_id": album_id,
            },
        )

    if response.status_code == 200:
        print(f"Image téléchargée avec succès: {image_path}")
    else:
        print(f"Erreur lors du téléchargement de l'image: {image_path}")

# Remplacez 'images_folder' par le chemin d'accès à votre dossier d'images
images_folder = "10k"

for image_path in os.listdir(images_folder):
    if os.path.isfile(os.path.join(images_folder, image_path)):
        upload_image(os.path.join(images_folder, image_path), album_id)
